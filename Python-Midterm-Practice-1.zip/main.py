# Midterm Practice 1 - Numbers - 1-20
print("~ ~ ~ ~ ~ ~ Midterm Practice 1 ~ ~ ~ ~ ~ ~\n")

print("  Number\t Double \t Triple")

number = 1
double = 2
triple = 3

for number in range(1,21):

	print("  ", number, "\t\t", double, "\t\t", triple)
	
	number = number + 1
	double = double + 2
	triple = triple + 3

print("\nThe End")