# 5.2 Debug 1

START_YEAR = 2015
FACTOR = 5
END_YEAR = 30
  
year= START_YEAR
yearGo = year + FACTOR
   
while (year <= END_YEAR):
	
	print('Year', year)