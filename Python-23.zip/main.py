print("\n* * * *  Test Average Calculator * * * *")
test1= int(input("\nEnter test score 1 or -1 to quit: "))
while (test1 >= 0):
  test2= int(input("Enter test score 2:"))
  test3= int(input("Enter test score 3:"))

  average = (test1 + test2 + test3)/3
  print("\n      * Average is " + str(round(average, 2)) + "  *\n")
  
  test1= int(input("Enter test score 1 or -1 to quit: "))
  
print("\nEnd of Program")