print("\n* * * * Clothing-For-Us Productivity Report * * * * ")

employeeName = str(input("\nEnter Employee's full name: "))
shifts = float(input("\nEnter number of shifts worked per month: "))
transactionMonth = float(input("\nEnter number of transaction month: "))
transactionValue = float(input("\nEnter dollar value of monthly transactions: "))