# This program computes the price of an item on sale 

DISC = (float(.20))
origPrice = float(input("Enter the Original Price: $"))

discount = origPrice * DISC
finalPrice = origPrice - discount

print("\nFinal Price After 20% Discount:  $", finalPrice)
